// mutation 常量

export const SET_MPVUEINFO = 'SET_MPVUEINFO';

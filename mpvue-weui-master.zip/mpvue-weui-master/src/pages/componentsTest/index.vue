<template>
  <div class="page">
    <mpvue-button type="primary" btnMsg="自定义文字" plain></mpvue-button>
  </div>
</template>

<script>
import mpvueButton from '@/components/button/button';
export default {
  data() {
    return {

    }
  },
  components: {
    mpvueButton
  }
}
</script>

<style>

</style>

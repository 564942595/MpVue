<template>
  <div class="page">
    <div class="weui-msg">
        <div class="weui-msg__icon-area">
            <icon type="success" size="93"></icon>
        </div>
        <div class="weui-msg__text-area">
            <div class="weui-msg__title">操作成功</div>
            <div class="weui-msg__desc">内容详情，可根据实际需要安排，如果换行则不超过规定长度，居中展现<navigator url="" class="weui-msg__link">文字链接</navigator></div>
        </div>
        <div class="weui-msg__opr-area">
            <div class="weui-btn-area">
                <button class="weui-btn" type="primary">推荐操作</button>
                <button class="weui-btn" type="default">辅助操作</button>
            </div>
        </div>
        <div class="weui-msg__extra-area">
            <div class="weui-footer">
                <div class="weui-footer__links">
                    <navigator url="" class="weui-footer__link">底部链接文本</navigator>
                </div>
                <div class="weui-footer__text">Copyright © 2008-2018 weui.io</div>
            </div>
        </div>
    </div>
</div>
</template>

<script>
export default {

}
</script>

<style>

</style>

<template>
  <div class="page">
    <div class="page__hd">
      <div class="page__title">Loadmore</div>
      <div class="page__desc">加载更多</div>
    </div>
    <div class="page__bd">
      <div class="weui-loadmore">
        <div class="weui-loading"></div>
        <div class="weui-loadmore__tips">正在加载</div>
      </div>
      <div class="weui-loadmore weui-loadmore_line">
        <div class="weui-loadmore__tips weui-loadmore__tips_in-line">暂无数据</div>
      </div>
      <div class="weui-loadmore weui-loadmore_line weui-loadmore_dot">
        <div class="weui-loadmore__tips weui-loadmore__tips_in-line weui-loadmore__tips_in-dot"></div>
      </div>
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
